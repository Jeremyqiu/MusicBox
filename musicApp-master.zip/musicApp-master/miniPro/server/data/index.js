module.exports={

  banner: [
    { url: "http://yanxuan.nosdn.127.net/65091eebc48899298171c2eb6696fe27.jpg" },
    { url: "http://yanxuan.nosdn.127.net/bff2e49136fcef1fd829f5036e07f116.jpg" },
    { url: "http://yanxuan.nosdn.127.net/bff2e49136fcef1fd829f5036e07f116.jpg" }
    ],
      hotSongs:[
        {
          id: 10011,
          name: "H3M",
          singer: "陈奕迅",
          categoryId: 10010,
          gallery: [], // 系列相关图片
          listPicUrl: "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=976975328,2385022262&fm=27&gp=0.jpg"
        },
        {
          id: 10021,
          name: "新的心跳",
          singer: "邓紫棋",
          categoryId: 10020,
          gallery: [], // 系列相关图片
          listPicUrl: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1523899412138&di=c40392fda53558085a2137fe97e268ad&imgtype=0&src=http%3A%2F%2Fupload.ct.youth.cn%2F2015%2F0725%2F1437795369215.jpg"
        },
        {
          id: 10031,
          name: "心跳",
          singer: "王力宏",
          categoryId: 10030,
          gallery: [], // 系列相关图片
          listPicUrl: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1523899279560&di=469892e990b844447fcc32de5f03f183&imgtype=0&src=http%3A%2F%2Fpic.baike.soso.com%2Fp%2F20140105%2F20140105080441-1948394824.jpg"
        }
      ],
      title: '我爱吉他'
  }